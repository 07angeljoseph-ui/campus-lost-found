from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), default="user", nullable=False)  # "user" or "admin"
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    lost_items = db.relationship("LostItem", backref="reporter", lazy=True)
    found_items = db.relationship("FoundItem", backref="reporter", lazy=True)
    notifications = db.relationship("Notification", backref="user", lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == "admin"


CATEGORIES = [
    "Electronics", "Bags & Backpacks", "ID Cards / Documents", "Keys",
    "Clothing & Accessories", "Books & Stationery", "Water Bottles / Flasks",
    "Jewelry & Watches", "Sports Equipment", "Other",
]


class LostItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    category = db.Column(db.String(60), nullable=False)
    description = db.Column(db.Text, nullable=False)
    location = db.Column(db.String(150), nullable=False)  # where it was lost
    date_lost = db.Column(db.Date, nullable=False)
    image_filename = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), default="open")  # open, resolved
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    reporter_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

    matches = db.relationship("Match", backref="lost_item", lazy=True,
                               foreign_keys="Match.lost_item_id")


class FoundItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    category = db.Column(db.String(60), nullable=False)
    description = db.Column(db.Text, nullable=False)
    location = db.Column(db.String(150), nullable=False)  # where it was found
    holding_location = db.Column(db.String(150), nullable=True)  # where it's kept now
    date_found = db.Column(db.Date, nullable=False)
    image_filename = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), default="open")  # open, resolved
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    reporter_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

    matches = db.relationship("Match", backref="found_item", lazy=True,
                               foreign_keys="Match.found_item_id")


class Match(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    lost_item_id = db.Column(db.Integer, db.ForeignKey("lost_item.id"), nullable=False)
    found_item_id = db.Column(db.Integer, db.ForeignKey("found_item.id"), nullable=False)
    score = db.Column(db.Integer, nullable=False)  # 0-100
    status = db.Column(db.String(20), default="pending")  # pending, confirmed, rejected
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (db.UniqueConstraint("lost_item_id", "found_item_id", name="uq_match_pair"),)


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    message = db.Column(db.String(300), nullable=False)
    link = db.Column(db.String(200), nullable=True)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
