from functools import wraps

from flask import Blueprint, render_template, redirect, url_for, flash, abort
from flask_login import login_required, current_user

from app import db
from app.models import LostItem, FoundItem, Match, User, Notification
from app.matching import _notify

admin_bp = Blueprint("admin", __name__)


def admin_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            abort(403)
        return f(*args, **kwargs)
    return wrapped


@admin_bp.route("/")
@login_required
@admin_required
def dashboard():
    stats = {
        "total_lost": LostItem.query.count(),
        "total_found": FoundItem.query.count(),
        "open_lost": LostItem.query.filter_by(status="open").count(),
        "open_found": FoundItem.query.filter_by(status="open").count(),
        "resolved_lost": LostItem.query.filter_by(status="resolved").count(),
        "resolved_found": FoundItem.query.filter_by(status="resolved").count(),
        "total_users": User.query.count(),
        "pending_matches": Match.query.filter_by(status="pending").count(),
    }
    pending_matches = (Match.query.filter_by(status="pending")
                        .order_by(Match.score.desc()).limit(20).all())
    return render_template("admin/dashboard.html", stats=stats, pending_matches=pending_matches)


@admin_bp.route("/matches")
@login_required
@admin_required
def matches():
    all_matches = Match.query.order_by(Match.status.asc(), Match.score.desc()).all()
    return render_template("admin/matches.html", matches=all_matches)


@admin_bp.route("/matches/<int:match_id>/confirm", methods=["POST"])
@login_required
@admin_required
def confirm_match(match_id):
    m = Match.query.get_or_404(match_id)
    m.status = "confirmed"
    m.lost_item.status = "resolved"
    m.found_item.status = "resolved"

    _notify(m.lost_item.reporter_id,
            f"Great news! Your lost item '{m.lost_item.title}' has been matched and confirmed by admin.",
            link=url_for("items.lost_detail", item_id=m.lost_item.id))
    _notify(m.found_item.reporter_id,
            f"The item you found '{m.found_item.title}' has been matched and confirmed by admin.",
            link=url_for("items.found_detail", item_id=m.found_item.id))

    db.session.commit()
    flash("Match confirmed. Both reports marked as resolved.", "success")
    return redirect(url_for("admin.dashboard"))


@admin_bp.route("/matches/<int:match_id>/reject", methods=["POST"])
@login_required
@admin_required
def reject_match(match_id):
    m = Match.query.get_or_404(match_id)
    m.status = "rejected"
    db.session.commit()
    flash("Match rejected.", "info")
    return redirect(url_for("admin.dashboard"))


@admin_bp.route("/items")
@login_required
@admin_required
def all_items():
    lost_items = LostItem.query.order_by(LostItem.created_at.desc()).all()
    found_items = FoundItem.query.order_by(FoundItem.created_at.desc()).all()
    return render_template("admin/items.html", lost_items=lost_items, found_items=found_items)


@admin_bp.route("/users")
@login_required
@admin_required
def users():
    all_users = User.query.order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=all_users)
