import os
import uuid
from datetime import datetime

from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, abort
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename

from app import db
from app.models import LostItem, FoundItem, Match, CATEGORIES
from app.matching import run_matching_for_lost, run_matching_for_found

items_bp = Blueprint("items", __name__)


def _allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_EXTENSIONS"]


def _save_image(file_storage):
    if not file_storage or file_storage.filename == "":
        return None
    if not _allowed_file(file_storage.filename):
        flash("Unsupported image type. Use png, jpg, jpeg, gif or webp.", "warning")
        return None
    ext = file_storage.filename.rsplit(".", 1)[1].lower()
    filename = f"{uuid.uuid4().hex}.{ext}"
    filepath = os.path.join(current_app.config["UPLOAD_FOLDER"], filename)
    file_storage.save(filepath)
    return filename


def _parse_date(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None


@items_bp.route("/report/lost", methods=["GET", "POST"])
@login_required
def report_lost():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "")
        description = request.form.get("description", "").strip()
        location = request.form.get("location", "").strip()
        date_lost = _parse_date(request.form.get("date_lost"))

        if not all([title, category, description, location, date_lost]):
            flash("Please fill in all required fields with a valid date.", "danger")
            return render_template("items/report_lost.html", categories=CATEGORIES)

        image_filename = _save_image(request.files.get("image"))

        item = LostItem(
            title=title, category=category, description=description,
            location=location, date_lost=date_lost, image_filename=image_filename,
            reporter_id=current_user.id,
        )
        db.session.add(item)
        db.session.commit()

        run_matching_for_lost(item)

        flash("Lost item reported. We'll notify you if a match turns up!", "success")
        return redirect(url_for("items.lost_detail", item_id=item.id))

    return render_template("items/report_lost.html", categories=CATEGORIES)


@items_bp.route("/report/found", methods=["GET", "POST"])
@login_required
def report_found():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        category = request.form.get("category", "")
        description = request.form.get("description", "").strip()
        location = request.form.get("location", "").strip()
        holding_location = request.form.get("holding_location", "").strip()
        date_found = _parse_date(request.form.get("date_found"))

        if not all([title, category, description, location, date_found]):
            flash("Please fill in all required fields with a valid date.", "danger")
            return render_template("items/report_found.html", categories=CATEGORIES)

        image_filename = _save_image(request.files.get("image"))

        item = FoundItem(
            title=title, category=category, description=description,
            location=location, holding_location=holding_location or "Admin office",
            date_found=date_found, image_filename=image_filename,
            reporter_id=current_user.id,
        )
        db.session.add(item)
        db.session.commit()

        run_matching_for_found(item)

        flash("Found item reported. Thank you for helping reunite it with its owner!", "success")
        return redirect(url_for("items.found_detail", item_id=item.id))

    return render_template("items/report_found.html", categories=CATEGORIES)


@items_bp.route("/lost/<int:item_id>")
def lost_detail(item_id):
    item = LostItem.query.get_or_404(item_id)
    matches = (Match.query.filter_by(lost_item_id=item.id)
               .order_by(Match.score.desc()).all())
    return render_template("items/lost_detail.html", item=item, matches=matches)


@items_bp.route("/found/<int:item_id>")
def found_detail(item_id):
    item = FoundItem.query.get_or_404(item_id)
    matches = (Match.query.filter_by(found_item_id=item.id)
               .order_by(Match.score.desc()).all())
    return render_template("items/found_detail.html", item=item, matches=matches)


@items_bp.route("/lost/<int:item_id>/resolve", methods=["POST"])
@login_required
def resolve_lost(item_id):
    item = LostItem.query.get_or_404(item_id)
    if item.reporter_id != current_user.id and not current_user.is_admin:
        abort(403)
    item.status = "resolved"
    db.session.commit()
    flash("Marked as resolved. Glad it's sorted!", "success")
    return redirect(url_for("items.lost_detail", item_id=item.id))


@items_bp.route("/found/<int:item_id>/resolve", methods=["POST"])
@login_required
def resolve_found(item_id):
    item = FoundItem.query.get_or_404(item_id)
    if item.reporter_id != current_user.id and not current_user.is_admin:
        abort(403)
    item.status = "resolved"
    db.session.commit()
    flash("Marked as resolved. Thanks for closing the loop!", "success")
    return redirect(url_for("items.found_detail", item_id=item.id))
