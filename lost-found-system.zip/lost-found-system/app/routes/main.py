from flask import Blueprint, render_template, redirect, url_for, request
from flask_login import login_required, current_user

from app import db
from app.models import LostItem, FoundItem, Notification, CATEGORIES

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    if current_user.is_authenticated:
        return redirect(url_for("main.dashboard"))
    recent_lost = LostItem.query.filter_by(status="open").order_by(LostItem.created_at.desc()).limit(6).all()
    recent_found = FoundItem.query.filter_by(status="open").order_by(FoundItem.created_at.desc()).limit(6).all()
    return render_template("index.html", recent_lost=recent_lost, recent_found=recent_found)


@main_bp.route("/dashboard")
@login_required
def dashboard():
    my_lost = LostItem.query.filter_by(reporter_id=current_user.id).order_by(LostItem.created_at.desc()).all()
    my_found = FoundItem.query.filter_by(reporter_id=current_user.id).order_by(FoundItem.created_at.desc()).all()
    unread_count = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
    return render_template("dashboard.html", my_lost=my_lost, my_found=my_found, unread_count=unread_count)


@main_bp.route("/browse")
def browse():
    q = request.args.get("q", "").strip()
    category = request.args.get("category", "")
    kind = request.args.get("kind", "lost")  # 'lost' or 'found'

    if kind == "found":
        query = FoundItem.query.filter_by(status="open")
    else:
        query = LostItem.query.filter_by(status="open")

    if category:
        query = query.filter_by(category=category)
    if q:
        like = f"%{q}%"
        Model = FoundItem if kind == "found" else LostItem
        query = query.filter(db.or_(Model.title.ilike(like), Model.description.ilike(like), Model.location.ilike(like)))

    items = query.order_by((FoundItem if kind == "found" else LostItem).created_at.desc()).all()
    return render_template("browse.html", items=items, kind=kind, q=q, category=category, categories=CATEGORIES)


@main_bp.route("/notifications")
@login_required
def notifications():
    notes = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    for n in notes:
        n.is_read = True
    db.session.commit()
    return render_template("notifications.html", notes=notes)
